<?php
// This file is for debugging only - remove in production
// Access this file directly via: /wp-content/plugins/names-fusion/debug.php

// Basic security check
if (!isset($_GET['debug_token']) || $_GET['debug_token'] !== 'namesfusion2024') {
    die('Unauthorized access');
}

// Only show errors in debug mode
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Function to check directory and file permissions
function check_permissions($path) {
    if (!file_exists($path)) {
        return "Does not exist: $path";
    }
    
    $perms = substr(sprintf('%o', fileperms($path)), -4);
    $is_readable = is_readable($path) ? 'Yes' : 'No';
    $is_writable = is_writable($path) ? 'Yes' : 'No';
    
    return "Exists: $path (Permissions: $perms, Readable: $is_readable, Writable: $is_writable)";
}

// Define plugin paths
define('PLUGIN_DIR', dirname(__FILE__));
define('REACT_BUILD_DIR', PLUGIN_DIR . '/react-build');
define('REACT_ASSETS_DIR', REACT_BUILD_DIR . '/assets');

echo '<h1>Names Fusion Debug Information</h1>';

echo '<h2>PHP Version</h2>';
echo '<p>' . phpversion() . '</p>';

// Check for duplicate plugin installations
echo '<h2>Checking for Duplicate Plugin Installations</h2>';
$plugin_folder_parent = dirname(PLUGIN_DIR);
$plugin_name_lowercase = 'names-fusion';
$plugin_name_capitalized = 'Names-Fusion';

// First check direct folder existence
$lowercase_exists = is_dir($plugin_folder_parent . '/' . $plugin_name_lowercase);
$capitalized_exists = is_dir($plugin_folder_parent . '/' . $plugin_name_capitalized);

// Additional check: Search all plugin directories, case-insensitive
$all_plugin_folders = scandir($plugin_folder_parent);
$all_name_fusion_folders = array();

foreach ($all_plugin_folders as $folder) {
    if ($folder === '.' || $folder === '..') continue;
    
    // Perform case-insensitive comparison
    if (strtolower($folder) === 'names-fusion') {
        $all_name_fusion_folders[] = $folder;
    }
}

echo '<div style="background-color: ' . ((count($all_name_fusion_folders) > 1) ? '#ffdddd' : '#ddffdd') . '; padding: 15px; border-radius: 5px; margin: 10px 0;">';
echo '<p><strong>Plugin folder with lowercase name (names-fusion):</strong> ' . ($lowercase_exists ? 'EXISTS' : 'Not found') . '</p>';
echo '<p><strong>Plugin folder with capitalized name (Names-Fusion):</strong> ' . ($capitalized_exists ? 'EXISTS' : 'Not found') . '</p>';

if (count($all_name_fusion_folders) > 1) {
    echo '<div style="color: #cc0000; font-weight: bold; margin-top: 10px;">';
    echo '<p>⚠️ CRITICAL ISSUE DETECTED: Multiple versions of the plugin detected with different capitalization!</p>';
    echo '<p>Found these folders that might be causing conflicts:</p>';
    echo '<ul>';
    foreach ($all_name_fusion_folders as $folder) {
        echo '<li>' . $plugin_folder_parent . '/' . $folder . '</li>';
    }
    echo '</ul>';
    echo '<p>This is likely causing the "Cannot redeclare names_fusion_shortcode()" fatal error.</p>';
    echo '<h3>How to fix:</h3>';
    echo '<ol>';
    echo '<li>Deactivate all plugins named "Names Fusion" from WordPress admin (if possible)</li>';
    echo '<li>Using FTP or your hosting file manager, delete ALL folders EXCEPT ONE (preferably keep: ' . $plugin_folder_parent . '/' . $plugin_name_lowercase . ')</li>';
    echo '<li>Restart your web server if possible or wait a few minutes</li>';
    echo '<li>Try activating the plugin again</li>';
    echo '</ol>';
    echo '</div>';
} else {
    echo '<p>✅ No duplicate plugin installations detected with different capitalization.</p>';
}
echo '</div>';

// Check WordPress options table for possible activated plugins with similar names
echo '<h3>WordPress Active Plugins Check</h3>';
echo '<p>Checking WordPress database for active plugins with similar names...</p>';

if (function_exists('get_option')) {
    $active_plugins = get_option('active_plugins');
    $count_name_fusion = 0;
    $active_name_fusion = array();
    
    if (is_array($active_plugins)) {
        foreach ($active_plugins as $plugin) {
            if (stripos($plugin, 'names-fusion') !== false) {
                $count_name_fusion++;
                $active_name_fusion[] = $plugin;
            }
        }
        
        if ($count_name_fusion > 1) {
            echo '<div style="background-color: #ffdddd; padding: 15px; border-radius: 5px; margin: 10px 0;">';
            echo '<p>⚠️ Multiple Names Fusion plugins are active in WordPress:</p>';
            echo '<ul>';
            foreach ($active_name_fusion as $plugin) {
                echo '<li>' . $plugin . '</li>';
            }
            echo '</ul>';
            echo '<p>This is likely causing the function redeclaration error. Deactivate all but one from the WordPress admin.</p>';
            echo '</div>';
        } else if ($count_name_fusion === 1) {
            echo '<p>✅ Only one Names Fusion plugin is active: ' . $active_name_fusion[0] . '</p>';
        } else {
            echo '<p>No Names Fusion plugins are currently active.</p>';
        }
    } else {
        echo '<p>Could not retrieve active plugins.</p>';
    }
} else {
    echo '<p>WordPress functions not available - cannot check active plugins.</p>';
}

echo '<h2>Fatal Error Check</h2>';
echo '<p>Checking for common function redeclaration issues...</p>';

// Get all PHP files in the plugin directory
function get_php_files($dir) {
    $result = array();
    $files = scandir($dir);
    foreach ($files as $file) {
        if ($file == '.' || $file == '..') continue;
        $path = $dir . '/' . $file;
        if (is_dir($path)) {
            $result = array_merge($result, get_php_files($path));
        } else if (pathinfo($path, PATHINFO_EXTENSION) == 'php') {
            $result[] = $path;
        }
    }
    return $result;
}

$php_files = get_php_files(PLUGIN_DIR);
$functions = array();
$potential_duplicates = array();

foreach ($php_files as $file) {
    $content = file_get_contents($file);
    preg_match_all('/function\s+([a-zA-Z0-9_]+)\s*\(/i', $content, $matches);
    if (!empty($matches[1])) {
        foreach ($matches[1] as $function_name) {
            if (!isset($functions[$function_name])) {
                $functions[$function_name] = $file;
            } else {
                $potential_duplicates[$function_name] = array(
                    'first' => $functions[$function_name],
                    'second' => $file
                );
            }
        }
    }
}

if (!empty($potential_duplicates)) {
    echo '<div style="background-color: #ffdddd; padding: 15px; border-radius: 5px; margin: 10px 0;">';
    echo '<p>⚠️ Potential function redeclarations found within this plugin:</p>';
    echo '<ul>';
    foreach ($potential_duplicates as $func => $files) {
        echo '<li><strong>' . $func . '()</strong> declared in:<br>';
        echo '- ' . str_replace(PLUGIN_DIR, '[plugin]', $files['first']) . '<br>';
        echo '- ' . str_replace(PLUGIN_DIR, '[plugin]', $files['second']) . '</li>';
    }
    echo '</ul>';
    echo '</div>';
} else {
    echo '<p>✅ No duplicate function declarations found within this plugin instance.</p>';
}

// Check for function declarations in other plugins
echo '<h3>Cross-Plugin Function Check</h3>';
echo '<p>Checking if functions defined in this plugin might exist in other plugins...</p>';

// Try to check other plugins (if we can access parent directory)
$other_plugins_dir = dirname(PLUGIN_DIR);
if (is_readable($other_plugins_dir)) {
    $plugins = scandir($other_plugins_dir);
    $other_functions = array();
    
    foreach ($plugins as $plugin) {
        if ($plugin === '.' || $plugin === '..' || $plugin === basename(PLUGIN_DIR)) continue;
        
        $plugin_dir = $other_plugins_dir . '/' . $plugin;
        if (is_dir($plugin_dir)) {
            $other_plugin_files = get_php_files($plugin_dir);
            
            foreach ($other_plugin_files as $file) {
                $content = file_get_contents($file);
                preg_match_all('/function\s+([a-zA-Z0-9_]+)\s*\(/i', $content, $matches);
                if (!empty($matches[1])) {
                    foreach ($matches[1] as $function_name) {
                        if (isset($functions[$function_name])) {
                            $other_functions[$function_name] = array(
                                'our_plugin' => $functions[$function_name],
                                'other_plugin' => array(
                                    'name' => $plugin,
                                    'file' => $file
                                )
                            );
                        }
                    }
                }
            }
        }
    }
    
    if (!empty($other_functions)) {
        echo '<div style="background-color: #ffdddd; padding: 15px; border-radius: 5px; margin: 10px 0;">';
        echo '<p>⚠️ Functions in this plugin CONFLICT with functions in other plugins:</p>';
        echo '<ul>';
        foreach ($other_functions as $func => $details) {
            echo '<li><strong>' . $func . '()</strong> is declared in:<br>';
            echo '- This plugin: ' . str_replace(PLUGIN_DIR, '[this-plugin]', $details['our_plugin']) . '<br>';
            echo '- Other plugin: ' . $details['other_plugin']['name'] . ' in ' . str_replace($details['other_plugin']['file'], '[other-plugin]', $details['other_plugin']['file']) . '</li>';
        }
        echo '</ul>';
        echo '<p>This is likely causing the function redeclaration error. Deactivate one of the conflicting plugins.</p>';
        echo '</div>';
    } else {
        echo '<p>✅ No function conflicts found with other plugins.</p>';
    }
} else {
    echo '<p>Cannot read other plugins directory. Limited check performed.</p>';
}

echo '<h2>Check for Residual/Cached Plugin Files</h2>';
echo '<p>Sometimes WordPress caches plugin files or doesn\'t fully delete them...</p>';

// Check for temporary plugin files in the wp-content directory
$wp_content_dir = dirname(dirname(PLUGIN_DIR)); // Go up two levels from plugin dir
$temp_dirs = array(
    $wp_content_dir . '/upgrade',
    $wp_content_dir . '/cache',
    $wp_content_dir . '/uploads/cache',
);

$found_residual = false;
foreach ($temp_dirs as $dir) {
    if (is_dir($dir) && is_readable($dir)) {
        echo '<p>Checking: ' . $dir . '</p>';
        $files = glob($dir . '/*names*fusion*', GLOB_NOSORT);
        
        if (!empty($files)) {
            $found_residual = true;
            echo '<div style="background-color: #ffdddd; padding: 10px; border-radius: 5px; margin: 5px 0;">';
            echo '<p>Found potential residual files:</p>';
            echo '<ul>';
            foreach ($files as $file) {
                echo '<li>' . $file . '</li>';
            }
            echo '</ul>';
            echo '</div>';
        }
    }
}

if (!$found_residual) {
    echo '<p>✅ No residual cached plugin files detected.</p>';
}

echo '<h2>Recommendation</h2>';
echo '<div style="background-color: #e6f7ff; padding: 15px; border-radius: 5px; margin: 10px 0;">';
echo '<p><strong>Based on your error message:</strong> "Cannot redeclare names_fusion_shortcode()"</p>';
echo '<ol>';
echo '<li>Make sure ALL versions of Names Fusion plugin are deactivated in WordPress admin</li>';
echo '<li>Delete ALL versions of the plugin from the plugins directory using FTP/File Manager</li>';
echo '<li>Clear WordPress cache (if using a caching plugin)</li>';
echo '<li>Upload a fresh copy of ONLY the lowercase "names-fusion" plugin</li>';
echo '<li>If issues persist, consider temporarily renaming the shortcode function in names-fusion.php from "names_fusion_shortcode" to something unique like "names_fusion_tool_shortcode"</li>';
echo '</ol>';
echo '</div>';

echo '<h2>Server Information</h2>';
echo '<pre>' . print_r($_SERVER, true) . '</pre>';

echo '<h2>Directory Structure</h2>';
echo '<ul>';
echo '<li>' . check_permissions(PLUGIN_DIR) . '</li>';
echo '<li>' . check_permissions(PLUGIN_DIR . '/css') . '</li>';
echo '<li>' . check_permissions(PLUGIN_DIR . '/js') . '</li>';
echo '<li>' . check_permissions(REACT_BUILD_DIR) . '</li>';
echo '<li>' . check_permissions(REACT_ASSETS_DIR) . '</li>';
echo '</ul>';

echo '<h2>React Build Files</h2>';
if (file_exists(REACT_ASSETS_DIR)) {
    $files = scandir(REACT_ASSETS_DIR);
    echo '<ul>';
    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            echo '<li>' . check_permissions(REACT_ASSETS_DIR . '/' . $file) . '</li>';
        }
    }
    echo '</ul>';
} else {
    echo '<p>React assets directory does not exist.</p>';
}

echo '<h2>PHP Error Log (last 50 lines)</h2>';
$error_log = ini_get('error_log');
if (file_exists($error_log) && is_readable($error_log)) {
    $log_content = shell_exec('tail -n 50 ' . escapeshellarg($error_log));
    echo '<pre>' . htmlspecialchars($log_content) . '</pre>';
} else {
    echo '<p>Error log not accessible or not defined.</p>';
}

echo '<h2>WordPress Debug Log (if exists)</h2>';
$wp_debug_log = WP_CONTENT_DIR . '/debug.log';
if (file_exists($wp_debug_log) && is_readable($wp_debug_log)) {
    $log_content = shell_exec('tail -n 50 ' . escapeshellarg($wp_debug_log));
    echo '<pre>' . htmlspecialchars($log_content) . '</pre>';
} else {
    echo '<p>WordPress debug log not accessible or not defined.</p>';
}
