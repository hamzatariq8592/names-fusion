(function($) {
    $(document).ready(function() {
        // DOM Elements
        const $word1 = $('#word1');
        const $word2 = $('#word2');
        const $minLength = $('#minLength');
        const $includeChars = $('#includeChars');
        const $lengthError = $('#lengthError');
        const $generateBtn = $('#generateBtn');
        const $savedIdeasBtn = $('#savedIdeasBtn');
        const $savedIdeasDropdown = $('#savedIdeasDropdown');
        const $savedIdeasList = $('#savedIdeasList');
        const $clearSavedBtn = $('#clearSavedBtn');
        const $downloadSavedBtn = $('#downloadSavedBtn');
        const $results = $('#results');
        const $resultsTitle = $('#resultsTitle');
        const $resultsCount = $('#resultsCount');
        const $savedCount = $('#savedCount');
        const $pagination = $('#pagination');
        const $toast = $('#toast');
        
        // State
        let combinations = [];
        let savedIdeas = [];
        let currentPage = 1;
        const resultsPerPage = 15;
        let isFirstGeneration = true;
        
        // Position the saved ideas dropdown relative to its button
        function positionDropdown() {
            const buttonWidth = $savedIdeasBtn.outerWidth();
            const dropdownWidth = buttonWidth * 1.5;
            
            // Set the dropdown width
            $savedIdeasDropdown.css({
                'width': dropdownWidth + 'px',
                'right': '0'
            });
        }
        
        // Load saved ideas from localStorage
        function loadSavedIdeas() {
            const saved = localStorage.getItem('namesFusionSavedIdeas');
            if (saved) {
                savedIdeas = JSON.parse(saved);
                updateSavedIdeasCount();
                renderSavedIdeasList();
            }
        }
        
        // Save ideas to localStorage
        function saveSavedIdeas() {
            localStorage.setItem('namesFusionSavedIdeas', JSON.stringify(savedIdeas));
            updateSavedIdeasCount();
        }
        
        // Update saved count display
        function updateSavedIdeasCount() {
            $savedCount.text(savedIdeas.length);
        }
        
        // Show toast notification
        function showToast(message) {
            $toast.text(message);
            $toast.addClass('show');
            
            setTimeout(function() {
                $toast.removeClass('show');
            }, 3000);
        }
        
        // Helper function to check if a string has consecutive duplicate characters
        function hasConsecutiveDuplicates(str) {
            for (let i = 0; i < str.length - 1; i++) {
                if (str[i] === str[i + 1]) {
                    return true;
                }
            }
            return false;
        }
        
        // Helper function to check balanced character contribution
        function hasBalancedContribution(part1, part2) {
            if (part1.length < 2 || part2.length < 2) {
                return false;
            }
            
            const uniqueCharsFromPart1 = new Set(part1.split('')).size;
            const uniqueCharsFromPart2 = new Set(part2.split('')).size;
            const totalUniqueChars = uniqueCharsFromPart1 + uniqueCharsFromPart2;
            
            // Each part should contribute at least 25% of the characters
            return uniqueCharsFromPart1 >= totalUniqueChars * 0.25 && 
                   uniqueCharsFromPart2 >= totalUniqueChars * 0.25;
        }
        
        // Helper function to ensure a combination starts with first letter of either word
        function startsWithFirstChar(part, word1, word2) {
            return part[0] === word1[0] || part[0] === word2[0];
        }
        
        // Helper function to ensure a combination ends with last letter of either word
        function endsWithLastChar(part, word1, word2) {
            const lastChar = part[part.length - 1];
            return lastChar === word1[word1.length - 1] || lastChar === word2[word2.length - 1];
        }
        
        // Helper function to remove duplicate characters (keep only first occurrence)
        function removeDuplicateChars(str) {
            const chars = new Set();
            let result = '';
            
            for (const char of str) {
                if (!chars.has(char)) {
                    chars.add(char);
                    result += char;
                }
            }
            
            return result;
        }
        
        // Helper function to check if a name is hard to pronounce
        function isHardToPronounce(name) {
            // Check for difficult consonant clusters (3+ consonants in a row)
            const consonantClusterRegex = /[bcdfghjklmnpqrstvwxz]{4,}/i;
            if (consonantClusterRegex.test(name)) return true;
            
            // Check for specific difficult consonant clusters
            const difficultPatterns = [
                /[ptk][ptk][ptk]/i,  // Three stops in a row
                /[ptk][szʃʒ][ptk]/i, // Stop-fricative-stop pattern
                /mpt/i, /rpt/i, /rkt/i, /mps/i, // Specific clusters
                /tch/i, /ngt/i, /ngk/i, /tzs/i, /tst/i, 
                /rmq/i, /rtq/i, /rqt/i, /mqt/i, /mqr/i,
                /hmtr/i, /mztr/i, /ztr/i, // Clusters from Hamza+Tariq
            ];
            
            for (const pattern of difficultPatterns) {
                if (pattern.test(name)) return true;
            }
            
            // Vowel-consonant balance check (too many consonants to vowels)
            const vowels = (name.match(/[aeiou]/gi) || []).length;
            const consonants = name.length - vowels;
            if (consonants >= vowels * 3 && consonants > 3) return true;
            
            // Lack of vowels between consonants
            const segments = name.split(/[aeiou]+/i).filter(s => s.length > 0);
            for (const segment of segments) {
                if (segment.length >= 3) return true; // 3+ consonants with no vowel
            }
            
            return false;
        }
        
        // Check if a name passes all rules
        function passesAllRules(name, word1, word2, minLength, includeCharsArray) {
            // Basic length check
            if (name.length < minLength) return false;
            
            // Check for consecutive duplicates
            if (hasConsecutiveDuplicates(name)) return false;
            
            // Must start with first char of either word
            if (!startsWithFirstChar(name, word1, word2)) return false;
            
            // Must end with last char of either word
            if (!endsWithLastChar(name, word1, word2)) return false;
            
            // Include specified characters check
            if (includeCharsArray.length > 0) {
                const includeCheck = includeCharsArray.every(char => {
                    if (char.length > 1 && !includeCharsArray.join(',').includes(',')) {
                        return name.includes(char);
                    }
                    return [...char].every(c => name.includes(c));
                });
                if (!includeCheck) return false;
            }
            
            // Check if the name is hard to pronounce
            if (isHardToPronounce(name)) return false;
            
            return true;
        }
        
        // Generate combinations function
        function generateCombinations() {
            const word1 = $word1.val().trim().toLowerCase();
            const word2 = $word2.val().trim().toLowerCase();
            const minLength = parseInt($minLength.val());
            const includeChars = $includeChars.val().trim();
            
            if (!word1 || !word2) {
                showToast('Please enter both words');
                return;
            }
            
            console.log(`Generating combinations for "${word1}" and "${word2}" with min length ${minLength}`);
            
            // Get all consecutive substrings from a word
            const getConsecutiveSubstrings = (word) => {
                const result = [];
                for (let i = 0; i < word.length; i++) {
                    for (let j = i + 1; j <= word.length; j++) {
                        const substring = word.substring(i, j);
                        result.push(substring);
                    }
                }
                return result;
            };
            
            const word1Substrings = getConsecutiveSubstrings(word1);
            const word2Substrings = getConsecutiveSubstrings(word2);
            
            // Separate collections for each first letter
            let word1FirstLetterNames = [];
            let word2FirstLetterNames = [];
            
            const includeCharsArray = includeChars 
                ? includeChars.toLowerCase().split(',').map(c => c.trim()).filter(c => c) 
                : [];
            
            // Exhaustive combination generation for word1's first letter
            for (const part1 of word1Substrings) {
                if (part1.length === 0 || part1[0] !== word1[0]) continue;
                
                for (const part2 of word2Substrings) {
                    if (part2.length === 0) continue;
                    
                    // Try different types of combinations
                    const combinations = [
                        part1 + part2, // Simple concatenation
                        removeDuplicateChars(part1 + part2), // Remove duplicates
                        // More mixed combinations
                        removeDuplicateChars(part1.substring(0, Math.ceil(part1.length/2)) + 
                                           part2.substring(0, Math.ceil(part2.length/2)) + 
                                           part1.substring(Math.ceil(part1.length/2)) + 
                                           part2.substring(Math.ceil(part2.length/2))),
                        // Interleaving first few characters
                        removeDuplicateChars(part1[0] + (part2[0] || '') + part1.substring(1) + part2.substring(1))
                    ];
                    
                    for (const combination of combinations) {
                        // Verify balanced contribution
                        const isBalanced = hasBalancedContribution(part1, part2);
                        if (!isBalanced) continue;
                        
                        // Apply all rules
                        if (!passesAllRules(combination, word1, word2, minLength, includeCharsArray)) continue;
                        
                        // Only add if not already in the list and starts with word1's first letter
                        if (combination[0] === word1[0] && !word1FirstLetterNames.includes(combination)) {
                            word1FirstLetterNames.push(combination);
                        }
                    }
                }
            }
            
            // Exhaustive combination generation for word2's first letter
            for (const part2 of word2Substrings) {
                if (part2.length === 0 || part2[0] !== word2[0]) continue;
                
                for (const part1 of word1Substrings) {
                    if (part1.length === 0) continue;
                    
                    // Try different types of combinations
                    const combinations = [
                        part2 + part1, // Simple concatenation
                        removeDuplicateChars(part2 + part1), // Remove duplicates
                        // More mixed combinations
                        removeDuplicateChars(part2.substring(0, Math.ceil(part2.length/2)) + 
                                           part1.substring(0, Math.ceil(part1.length/2)) + 
                                           part2.substring(Math.ceil(part2.length/2)) + 
                                           part1.substring(Math.ceil(part1.length/2))),
                        // Interleaving first few characters
                        removeDuplicateChars(part2[0] + (part1[0] || '') + part2.substring(1) + part1.substring(1))
                    ];
                    
                    for (const combination of combinations) {
                        // Verify balanced contribution
                        const isBalanced = hasBalancedContribution(part1, part2);
                        if (!isBalanced) continue;
                        
                        // Apply all rules
                        if (!passesAllRules(combination, word1, word2, minLength, includeCharsArray)) continue;
                        
                        // Only add if not already in the list and starts with word2's first letter
                        if (combination[0] === word2[0] && !word2FirstLetterNames.includes(combination)) {
                            word2FirstLetterNames.push(combination);
                        }
                    }
                }
            }
            
            // Sort each group alphabetically
            word1FirstLetterNames.sort((a, b) => a.localeCompare(b));
            word2FirstLetterNames.sort((a, b) => a.localeCompare(b));
            
            console.log(`Generated names starting with ${word1[0]}: ${word1FirstLetterNames.length}`);
            console.log(`Generated names starting with ${word2[0]}: ${word2FirstLetterNames.length}`);
            
            // Generate more combinations if either collection is small
            // For word2 first letter names
            if (word2FirstLetterNames.length < 20) {
                console.log(`Generating extra combinations for ${word2[0]} first letter`);
                for (const part2 of word2Substrings.filter(s => s[0] === word2[0])) {
                    for (const part1 of word1Substrings) {
                        // Try alternate patterns
                        for (let i = 1; i < part2.length; i++) {
                            const prefix = part2.substring(0, i);
                            const suffix = part2.substring(i);
                            
                            // Pattern: [prefix from word2] + [part from word1] + [suffix from word2]
                            const mixed = prefix + part1 + suffix;
                            const combination = removeDuplicateChars(mixed);
                            
                            if (combination[0] !== word2[0]) continue;
                            if (!passesAllRules(combination, word1, word2, minLength, includeCharsArray)) continue;
                            
                            // More relaxed contribution check for additional combinations
                            const contribution1 = new Set(part1.split('')).size;
                            const contribution2 = new Set(part2.split('')).size;
                            
                            if (contribution1 < 1 || contribution2 < 1) continue;
                            
                            if (!word2FirstLetterNames.includes(combination)) {
                                word2FirstLetterNames.push(combination);
                            }
                        }
                        
                        // Advanced pattern: interleave characters from both words
                        // This makes sure we have a good mix while still starting with word2
                        const chars1 = [...part1];
                        const chars2 = [...part2];
                        let interleaved = chars2[0]; // Start with first char of word2
                        
                        for (let i = 1; i < Math.max(chars1.length, chars2.length); i++) {
                            if (i < chars1.length) interleaved += chars1[i];
                            if (i < chars2.length) interleaved += chars2[i];
                        }
                        
                        const combination = removeDuplicateChars(interleaved);
                        if (passesAllRules(combination, word1, word2, minLength, includeCharsArray) && 
                            !word2FirstLetterNames.includes(combination)) {
                            word2FirstLetterNames.push(combination);
                        }
                    }
                }
            }
            
            // For word1 first letter names
            if (word1FirstLetterNames.length < 20) {
                console.log(`Generating extra combinations for ${word1[0]} first letter`);
                for (const part1 of word1Substrings.filter(s => s[0] === word1[0])) {
                    for (const part2 of word2Substrings) {
                        // Try alternate patterns
                        for (let i = 1; i < part1.length; i++) {
                            const prefix = part1.substring(0, i);
                            const suffix = part1.substring(i);
                            
                            // Pattern: [prefix from word1] + [part from word2] + [suffix from word1]
                            const mixed = prefix + part2 + suffix;
                            const combination = removeDuplicateChars(mixed);
                            
                            if (combination[0] !== word1[0]) continue;
                            if (!passesAllRules(combination, word1, word2, minLength, includeCharsArray)) continue;
                            
                            // More relaxed contribution check for additional combinations
                            const contribution1 = new Set(part1.split('')).size;
                            const contribution2 = new Set(part2.split('')).size;
                            
                            if (contribution1 < 1 || contribution2 < 1) continue;
                            
                            if (!word1FirstLetterNames.includes(combination)) {
                                word1FirstLetterNames.push(combination);
                            }
                        }
                        
                        // Advanced pattern: interleave characters from both words
                        // This makes sure we have a good mix while still starting with word1
                        const chars1 = [...part1];
                        const chars2 = [...part2];
                        let interleaved = chars1[0]; // Start with first char of word1
                        
                        for (let i = 1; i < Math.max(chars1.length, chars2.length); i++) {
                            if (i < chars2.length) interleaved += chars2[i];
                            if (i < chars1.length) interleaved += chars1[i];
                        }
                        
                        const combination = removeDuplicateChars(interleaved);
                        if (passesAllRules(combination, word1, word2, minLength, includeCharsArray) && 
                            !word1FirstLetterNames.includes(combination)) {
                            word1FirstLetterNames.push(combination);
                        }
                    }
                }
            }
            
            // Sort again after adding more combinations
            word1FirstLetterNames.sort((a, b) => a.localeCompare(b));
            word2FirstLetterNames.sort((a, b) => a.localeCompare(b));
            
            console.log(`After additional generation - names starting with ${word1[0]}: ${word1FirstLetterNames.length}`);
            console.log(`After additional generation - names starting with ${word2[0]}: ${word2FirstLetterNames.length}`);
            
            // Create balanced final results
            const totalNamesTarget = 40; // Target approximately 40 total names
            
            // Calculate how many names to take from each collection
            // Aim for 50/50 distribution if possible, with a minimum of 40% from each word
            const minPercentage = 0.4; // Ensure at least 40% representation from each letter
            
            // Calculate maximum per collection to maintain balance
            const maxPerCollection = Math.floor(totalNamesTarget * (1 - minPercentage));
            
            // Calculate how many to take based on collection sizes and balance goals
            let word1Count, word2Count;
            
            // If either collection is smaller than the minimum representation, take all of it
            if (word1FirstLetterNames.length < totalNamesTarget * minPercentage) {
                word1Count = word1FirstLetterNames.length;
                word2Count = Math.min(word2FirstLetterNames.length, totalNamesTarget - word1Count);
            } else if (word2FirstLetterNames.length < totalNamesTarget * minPercentage) {
                word2Count = word2FirstLetterNames.length;
                word1Count = Math.min(word1FirstLetterNames.length, totalNamesTarget - word2Count);
            } else {
                // Both collections have enough names, aim for 50/50 split
                const totalAvailable = Math.min(totalNamesTarget, word1FirstLetterNames.length + word2FirstLetterNames.length);
                const halfTotal = Math.floor(totalAvailable / 2);
                
                word1Count = Math.min(word1FirstLetterNames.length, halfTotal);
                word2Count = Math.min(word2FirstLetterNames.length, halfTotal);
                
                // Adjust if we have leftover slots
                const remaining = totalAvailable - (word1Count + word2Count);
                if (remaining > 0) {
                    if (word1FirstLetterNames.length > word1Count) {
                        word1Count += remaining;
                    } else if (word2FirstLetterNames.length > word2Count) {
                        word2Count += remaining;
                    }
                }
            }
            
            // Take the selected number from each collection
            const selectedWord1Names = word1FirstLetterNames.slice(0, word1Count);
            const selectedWord2Names = word2FirstLetterNames.slice(0, word2Count);
            
            // Combine and sort for the final results
            combinations = [...selectedWord1Names, ...selectedWord2Names];
            combinations.sort((a, b) => a.localeCompare(b));
            
            console.log(`Final results - total: ${combinations.length}`);
            console.log(`Final results - starting with ${word1[0]}: ${selectedWord1Names.length}`);
            console.log(`Final results - starting with ${word2[0]}: ${selectedWord2Names.length}`);
            
            $resultsCount.text(combinations.length);
            currentPage = 1;
            renderPagination();
            renderResults();
            
            if (combinations.length === 0) {
                showToast('No matches found with current filters');
            }
            
            // After first generation, we'll set automatic updates
            if (isFirstGeneration) {
                isFirstGeneration = false;
                setupAutoUpdates();
            }
        }
        
        // Setup automatic updates after first manual generation
        function setupAutoUpdates() {
            // Add input event listeners for automatic updates
            $word1.on('input', debounce(generateCombinations, 500));
            $word2.on('input', debounce(generateCombinations, 500));
            $includeChars.on('input', debounce(generateCombinations, 500));
            // minLength already has its own handler that will call generateCombinations
        }
        
        // Simple debounce function to prevent too many updates
        function debounce(func, delay) {
            let timeout;
            return function() {
                const context = this;
                const args = arguments;
                clearTimeout(timeout);
                timeout = setTimeout(function() {
                    func.apply(context, args);
                }, delay);
            };
        }
        
        // Render results
        function renderResults() {
            $results.empty();
            
            const startIndex = (currentPage - 1) * resultsPerPage;
            const endIndex = Math.min(startIndex + resultsPerPage, combinations.length);
            const pageResults = combinations.slice(startIndex, endIndex);
            
            if (pageResults.length === 0) {
                $results.html('<div class="no-results">No combinations match your criteria</div>');
                return;
            }
            
            for (let i = 0; i < pageResults.length; i++) {
                const name = pageResults[i];
                const isFavorite = savedIdeas.includes(name);
                
                const $item = $('<div class="result-item"></div>');
                
                // Create name element
                const $name = $('<span class="result-item-name"></span>').text(name);
                
                // Create actions container
                const $actions = $('<div class="result-item-actions"></div>');
                
                // Create copy button
                const $copyBtn = $('<button class="copy-btn" title="Copy to clipboard"></button>');
                $copyBtn.html('<span class="dashicons dashicons-clipboard"></span>');
                $copyBtn.on('click', function() {
                    copyToClipboard(name);
                });
                
                // Create favorite button
                const $favoriteBtn = $('<button class="favorite-btn" title="Add to favorites"></button>');
                if (isFavorite) {
                    $favoriteBtn.addClass('active');
                }
                $favoriteBtn.html('<span class="dashicons dashicons-star-filled"></span>');
                $favoriteBtn.on('click', function(e) {
                    e.preventDefault(); // Prevent any potential form submission
                    e.stopPropagation(); // Stop event from bubbling up
                    toggleFavorite(name);
                    $(this).toggleClass('active');
                    return false; // Prevent default and stop propagation
                });
                
                // Append all elements
                $actions.append($copyBtn, $favoriteBtn);
                $item.append($name, $actions);
                $results.append($item);
            }
        }
        
        // Render pagination
        function renderPagination() {
            $pagination.empty();
            
            if (combinations.length === 0) {
                return;
            }
            
            const totalPages = Math.ceil(combinations.length / resultsPerPage);
            
            // Only show pagination if we have more than one page
            if (totalPages <= 1) {
                return;
            }
            
            // Determine page range to display
            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            
            // Adjust start page if end page is maxed out
            if (endPage === totalPages) {
                startPage = Math.max(1, endPage - 4);
            }
            
            // Create page items
            for (let i = startPage; i <= endPage; i++) {
                const $pageItem = $('<span class="pagination-item"></span>').text(i);
                
                if (i === currentPage) {
                    $pageItem.addClass('active');
                }
                
                $pageItem.on('click', function() {
                    currentPage = i;
                    renderResults();
                    renderPagination();
                });
                
                $pagination.append($pageItem);
            }
        }
        
        // Toggle favorite status
        function toggleFavorite(name) {
            const index = savedIdeas.indexOf(name);
            
            if (index === -1) {
                // Add to favorites
                savedIdeas.push(name);
                showToast(`Added "${name}" to favorites`);
            } else {
                // Remove from favorites
                savedIdeas.splice(index, 1);
                showToast(`Removed "${name}" from favorites`);
            }
            
            saveSavedIdeas();
            renderSavedIdeasList();
            
            // Update button state directly without full re-render
            $('.result-item').each(function() {
                const itemName = $(this).find('.result-item-name').text();
                if (itemName === name) {
                    $(this).find('.favorite-btn').toggleClass('active');
                }
            });
        }
        
        // Render saved ideas list
        function renderSavedIdeasList() {
            $savedIdeasList.empty();
            
            if (savedIdeas.length === 0) {
                $savedIdeasList.html('<li class="no-saved">No saved ideas yet</li>');
                return;
            }
            
            for (let i = 0; i < savedIdeas.length; i++) {
                const name = savedIdeas[i];
                const $item = $('<li></li>');
                $item.html('<span class="dashicons dashicons-star-filled"></span>' + name);
                $savedIdeasList.append($item);
            }
        }
        
        // Copy to clipboard
        function copyToClipboard(text) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            
            showToast(`Copied "${text}" to clipboard`);
        }
        
        // Clear all saved ideas
        function clearAllSavedIdeas() {
            savedIdeas = [];
            saveSavedIdeas();
            renderSavedIdeasList();
            renderResults(); // Re-render to update favorite icons
            showToast('All saved ideas cleared');
        }
        
        // Download saved ideas
        function downloadSavedIdeas() {
            if (savedIdeas.length === 0) {
                showToast('No saved ideas to download');
                return;
            }
            
            const content = savedIdeas.join('\n');
            const blob = new Blob([content], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = 'names_fusion_ideas.txt';
            document.body.appendChild(a);
            a.click();
            
            setTimeout(function() {
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }, 100);
            
            showToast('Downloaded saved ideas');
        }
        
        // Event Handlers
        
        // Fix minimum length handling to prevent deletion of default value
        $minLength.on('input', function() {
            const value = $(this).val();
            
            if (value === '') {
                $(this).val(3); // Reset to default
                $lengthError.hide();
            } else {
                const numValue = parseInt(value);
                
                if (isNaN(numValue) || numValue < 2) {
                    $lengthError.show();
                } else {
                    $lengthError.hide();
                    // Only generate combinations if not first generation
                    if (!isFirstGeneration) {
                        generateCombinations();
                    }
                }
            }
        });
        
        // Handle Enter key in input fields
        $word1.add($word2).add($minLength).add($includeChars).on('keypress', function(e) {
            if (e.which === 13) { // Enter key
                generateCombinations();
                $(this).blur(); // Remove focus from input field
            }
        });
        
        // Generate combinations on button click
        $generateBtn.on('click', function() {
            generateCombinations();
        });
        
        // Toggle saved ideas dropdown
        $savedIdeasBtn.on('click', function(e) {
            e.preventDefault();
            positionDropdown(); // Position dropdown before showing it
            $savedIdeasDropdown.toggle();
            e.stopPropagation();
        });
        
        // Close saved ideas dropdown when clicking outside
        $(document).on('click', function(event) {
            if (!$(event.target).closest('#savedIdeasDropdown, #savedIdeasBtn').length) {
                $savedIdeasDropdown.hide();
            }
        });
        
        // Clear all saved ideas
        $clearSavedBtn.on('click', function() {
            clearAllSavedIdeas();
        });
        
        // Download saved ideas
        $downloadSavedBtn.on('click', function() {
            downloadSavedIdeas();
        });
        
        // Initialize
        loadSavedIdeas();
        
        // Call positionDropdown on window resize
        $(window).on('resize', positionDropdown);
    });
})(jQuery);
