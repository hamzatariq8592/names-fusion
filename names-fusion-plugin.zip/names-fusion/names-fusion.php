<?php
/**
 * Plugin Name: Names Fusion
 * Plugin URI: https://namesfusion.com
 * Description: A name combiner tool to generate creative name combinations. Use shortcode [names_fusion] for jQuery version or [names_fusion_react] for React version.
 * Version: 1.0
 * Author: Names Fusion Creator
 * Author URI: https://namesfusion.com
 * Text Domain: names-fusion
 * Domain Path: /languages
 */

// Enable error reporting for debugging
if (!defined('WP_DEBUG') || !WP_DEBUG) {
    // Only enable this temporarily for debugging
    ini_set('display_errors', 1);
    ini_set('error_reporting', E_ALL);
}

// Prevent direct access
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define plugin constants
define('NAMES_FUSION_VERSION', '1.0');
define('NAMES_FUSION_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('NAMES_FUSION_PLUGIN_URL', plugin_dir_url(__FILE__));

// Log activation function start
function names_fusion_debug_log($message) {
    if (function_exists('error_log')) {
        error_log('[Names Fusion Debug] ' . $message);
    }
}

// Register styles and scripts for jQuery version
function names_fusion_enqueue_scripts() {
    // Only load if not admin
    if (!is_admin()) {
        // Dashicons for WordPress built-in icons
        wp_enqueue_style('dashicons');
        wp_enqueue_style('names-fusion-styles', NAMES_FUSION_PLUGIN_URL . 'css/names-fusion.css', array(), NAMES_FUSION_VERSION);
        wp_enqueue_script('names-fusion-script', NAMES_FUSION_PLUGIN_URL . 'js/names-fusion.js', array('jquery'), NAMES_FUSION_VERSION, true);
    }
}
add_action('wp_enqueue_scripts', 'names_fusion_enqueue_scripts');

// Register shortcode for jQuery version - RENAMED to avoid conflicts
function names_fusion_tool_shortcode() {
    ob_start();
    ?>
    <div class="names-fusion-container">
        <div class="names-fusion-form">
            <div class="input-group">
                <label for="word1">First Word</label>
                <input type="text" id="word1" class="input-focus-ring" placeholder="Enter first word">
            </div>
            
            <div class="input-group">
                <label for="word2">Second Word</label>
                <input type="text" id="word2" class="input-focus-ring" placeholder="Enter second word">
            </div>
            
            <div class="input-group">
                <label for="minLength">Minimum Length (2+)</label>
                <input type="number" id="minLength" class="input-focus-ring" value="3" min="2">
                <p class="error-message" id="lengthError">Minimum length must be at least 2</p>
            </div>
            
            <div class="input-group">
                <label for="includeChars">Include Characters (Optional)</label>
                <input type="text" id="includeChars" class="input-focus-ring" placeholder="e.g. a,b,c or abc">
            </div>
            
            <div class="button-container">
                <button id="generateBtn" class="generate-btn">Generate Combinations</button>
            </div>
        </div>
        
        <div class="results-header">
            <h3 id="resultsTitle" class="results-title"><span id="resultsCount" class="results-count"></span> combinations</h3>
            <button id="savedIdeasBtn" class="saved-ideas-btn">
                <span class="dashicons dashicons-star-filled"></span> Saved Ideas (<span id="savedCount">0</span>)
            </button>
        </div>
        
        <div id="savedIdeasDropdown" class="saved-ideas-dropdown">
            <div class="saved-ideas-content">
                <h4>Saved Ideas</h4>
                <ul id="savedIdeasList"></ul>
                <div class="saved-ideas-actions">
                    <button id="clearSavedBtn" class="clear-btn">Clear All</button>
                    <button id="downloadSavedBtn" class="download-btn">Download All</button>
                </div>
            </div>
        </div>
        
        <div id="results" class="results-container"></div>
        
        <div id="pagination" class="pagination-container"></div>
        
        <div id="toast" class="toast-notification"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('names_fusion', 'names_fusion_tool_shortcode');

// For embedding React version - register a shortcode that loads React app container
function names_fusion_react_shortcode() {
    // Ensure scripts are loaded for this shortcode
    names_fusion_react_enqueue_assets();
    
    // Create a div with specific styling to ensure proper rendering
    return '<div id="names-fusion-react-root" class="names-fusion-react-container" style="position: relative; z-index: 1;"></div>';
}
add_shortcode('names_fusion_react', 'names_fusion_react_shortcode');

// Function to find React assets in the build directory
function names_fusion_get_react_assets() {
    $assets = array(
        'css' => null,
        'js' => null
    );
    
    $assets_dir = NAMES_FUSION_PLUGIN_DIR . 'react-build/assets/';
    
    if (!is_dir($assets_dir)) {
        names_fusion_debug_log('Assets directory not found: ' . $assets_dir);
        return $assets;
    }
    
    // Scan the assets directory
    $files = scandir($assets_dir);
    
    if (!$files) {
        names_fusion_debug_log('Failed to scan assets directory: ' . $assets_dir);
        return $assets;
    }
    
    // Look for the main CSS and JS files
    foreach ($files as $file) {
        if (preg_match('/index\..+\.css$/', $file)) {
            $assets['css'] = 'react-build/assets/' . $file;
        } elseif (preg_match('/index\..+\.js$/', $file)) {
            $assets['js'] = 'react-build/assets/' . $file;
        }
    }
    
    names_fusion_debug_log('Found CSS: ' . ($assets['css'] ? $assets['css'] : 'none'));
    names_fusion_debug_log('Found JS: ' . ($assets['js'] ? $assets['js'] : 'none'));
    
    return $assets;
}

// Function to enqueue React assets - now directly usable without checking for shortcode presence
function names_fusion_react_enqueue_assets() {
    static $assets_enqueued = false;
    
    // Only enqueue once per page load
    if ($assets_enqueued) {
        return;
    }
    
    $assets = names_fusion_get_react_assets();
    
    if ($assets['css']) {
        wp_enqueue_style(
            'names-fusion-react-styles', 
            NAMES_FUSION_PLUGIN_URL . $assets['css'], 
            array(), 
            NAMES_FUSION_VERSION
        );
    } else {
        names_fusion_debug_log('React CSS file not found!');
    }
    
    if ($assets['js']) {
        // Add a higher priority to ensure our script loads after others
        wp_enqueue_script(
            'names-fusion-react-main', 
            NAMES_FUSION_PLUGIN_URL . $assets['js'], 
            array(), 
            NAMES_FUSION_VERSION, 
            true
        );
        
        // Add inline script to help with portal creation
        wp_add_inline_script('names-fusion-react-main', '
            // Ensure portal root exists
            document.addEventListener("DOMContentLoaded", function() {
                if (!document.getElementById("names-fusion-portal-root")) {
                    var portalRoot = document.createElement("div");
                    portalRoot.id = "names-fusion-portal-root";
                    portalRoot.style.position = "fixed";
                    portalRoot.style.zIndex = "999999";
                    portalRoot.style.top = "0";
                    portalRoot.style.left = "0";
                    portalRoot.style.width = "100%";
                    portalRoot.style.pointerEvents = "none";
                    document.body.appendChild(portalRoot);
                }
            });
        ');
    } else {
        names_fusion_debug_log('React JS file not found!');
    }
    
    $assets_enqueued = true;
}

// Only check for shortcode in content to enqueue assets during wp_head, before rendering
function names_fusion_check_for_shortcode() {
    global $post;
    
    if (!is_a($post, 'WP_Post')) {
        return;
    }
    
    if (is_singular() && has_shortcode($post->post_content, 'names_fusion_react')) {
        names_fusion_react_enqueue_assets();
    }
}
add_action('wp_head', 'names_fusion_check_for_shortcode', 5);

// Create required directories on activation
function names_fusion_activation() {
    names_fusion_debug_log('Activation started');
    
    try {
        // Create directories if they don't exist
        $directories = array(
            'css' => NAMES_FUSION_PLUGIN_DIR . 'css',
            'js' => NAMES_FUSION_PLUGIN_DIR . 'js',
            'react_build' => NAMES_FUSION_PLUGIN_DIR . 'react-build',
            'react_assets' => NAMES_FUSION_PLUGIN_DIR . 'react-build/assets',
        );
        
        foreach ($directories as $dir_name => $dir_path) {
            names_fusion_debug_log('Checking directory: ' . $dir_path);
            
            if (!file_exists($dir_path)) {
                names_fusion_debug_log('Directory does not exist, creating: ' . $dir_path);
                
                if (!wp_mkdir_p($dir_path)) {
                    names_fusion_debug_log('Failed to create directory: ' . $dir_path);
                    continue;
                }
                
                // Create an index.php file to prevent directory listing
                $index_file = $dir_path . '/index.php';
                names_fusion_debug_log('Creating index.php in: ' . $index_file);
                
                if (!file_put_contents($index_file, '<?php // Silence is golden.')) {
                    names_fusion_debug_log('Failed to create index.php in: ' . $index_file);
                }
            } else {
                names_fusion_debug_log('Directory already exists: ' . $dir_path);
            }
        }
        
        // Ensure CSS file exists
        $css_file = $directories['css'] . '/names-fusion.css';
        names_fusion_debug_log('Checking CSS file: ' . $css_file);
        
        if (!file_exists($css_file)) {
            names_fusion_debug_log('CSS file does not exist, creating: ' . $css_file);
            if (!file_put_contents($css_file, '/* Names Fusion Styles */')) {
                names_fusion_debug_log('Failed to create CSS file: ' . $css_file);
            }
        }
        
        // Ensure JS file exists
        $js_file = $directories['js'] . '/names-fusion.js';
        names_fusion_debug_log('Checking JS file: ' . $js_file);
        
        if (!file_exists($js_file)) {
            names_fusion_debug_log('JS file does not exist, creating: ' . $js_file);
            if (!file_put_contents($js_file, '/* Names Fusion jQuery Script */')) {
                names_fusion_debug_log('Failed to create JS file: ' . $js_file);
            }
        }
        
        names_fusion_debug_log('Activation completed successfully');
    } catch (Exception $e) {
        names_fusion_debug_log('Activation error: ' . $e->getMessage() . ' at line ' . $e->getLine());
    }
}
register_activation_hook(__FILE__, 'names_fusion_activation');

// Add deactivation hook for cleanup if needed
function names_fusion_deactivation() {
    names_fusion_debug_log('Plugin deactivated');
}
register_deactivation_hook(__FILE__, 'names_fusion_deactivation');
